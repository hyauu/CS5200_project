DROP TABLE IF EXISTS `db_project`.`tables`;
CREATE TABLE `db_project`.`tables` (
 `id` INT NOT NULL AUTO_INCREMENT,
 `capacity` INT DEFAULT 0,
 PRIMARY KEY (`id`));