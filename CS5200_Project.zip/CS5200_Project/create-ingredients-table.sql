DROP TABLE IF EXISTS `db_project`.`ingredients`;
CREATE TABLE `db_project`.`ingredients` (
 `id` INT NOT NULL AUTO_INCREMENT,
 `name` VARCHAR(45) NULL,
 `description` VARCHAR(45) NULL,

 PRIMARY KEY (`id`));
 

